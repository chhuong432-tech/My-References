clc; clear; close all;

% ================= PARAMETERS =================
c  = 1;        % Chord length
t  = 0.12;     % Thickness ratio (12%)
m  = 0.04;     % Maximum camber (4%)
p  = 0.4;      % Location of max camber (40% chord)
n  = 300;      % Number of points

% ============== X DISTRIBUTION ================
beta = linspace(0, pi, n);
x = (c/2)*(1 - cos(beta));   % cosine spacing

% =========== THICKNESS DISTRIBUTION ===========
yt = 8*t*c*( ...
    0.2969*sqrt(x/c) ...
  - 0.1260*(x/c) ...
  - 0.3516*(x/c).^2 ...
  + 0.2843*(x/c).^3 ...
  - 0.1015*(x/c).^4 );

% ============== CAMBER LINE ===================
yc = zeros(size(x));
dyc_dx = zeros(size(x));

for i = 1:length(x)
    if x(i) <= p*c
        yc(i) = m*(x(i)/(p^2))*(2*p - x(i)/c);
        dyc_dx(i) = (2*m/(p^2))*(p - x(i)/c);
    else
        yc(i) = m*((c - x(i))/((1-p)^2))*(1 + x(i)/c - 2*p);
        dyc_dx(i) = (2*m/((1-p)^2))*(p - x(i)/c);
    end
end

theta = atan(dyc_dx);

% ========== UPPER & LOWER SURFACES ============
xu = x - yt.*sin(theta);
yu = yc + yt.*cos(theta);

xl = x + yt.*sin(theta);
yl = 3*yc - yt.*cos(theta);

% =================== PLOT =====================
figure;
plot(xu, yu, 'k', 'LineWidth', 2); hold on;
plot(xl, yl, 'k', 'LineWidth', 2);
plot(x, yc, '--', 'Color',[0.5 0.5 0.5]); % camber line

axis equal;
grid on;

% ----------- DOMAIN (AXIS LIMITS) -------------
xlim([-0.05 1.05])
ylim([-0.15 0.25])

xlabel('x / c');
ylabel('y / c');

title('Cambered Airfoil (NACA 4-Digit)');

