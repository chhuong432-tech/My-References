function SupersonicNozzleTimeGraphs
    % Time vector (seconds)
    t = 0:60;   % simulate 1 minute of flight

    % Altitude profile (linear climb: 5000 m → 15000 m in 60 s)
    h_range = linspace(5000,15000,length(t));

    % Constants
    Gamma = 1.4; Rgas = 287; g = 9.81; L = 0.0065;
    T0 = 288.15; P0 = 101325; Pt = 52529; A2_A3 = 3;

    % Preallocate
    n = length(h_range);
    Mach_inlet = zeros(1,n); Mach_throat = ones(1,n); Mach_outlet = zeros(1,n);
    Vel_inlet = zeros(1,n); Vel_throat = zeros(1,n); Vel_outlet = zeros(1,n);
    P_inlet = zeros(1,n); P_throat = zeros(1,n); P_outlet = zeros(1,n);
    T_inlet = zeros(1,n); T_throat = zeros(1,n); T_outlet = zeros(1,n);

    % Loop over time/altitude
    for i = 1:n
        h = h_range(i);
        T1 = T0 - L*h;
        Ps = P0 * (T1/T0)^(g/(L*Rgas));
        phi = Ps / (Rgas*T1);
        C = sqrt(Gamma * Rgas * T1);
        P1 = Ps;
        V1 = sqrt(2*((-Pt+Ps))/phi);
        M1 = V1/C;

        T01 = T1*(1+((Gamma-1)/2)*M1^2);
        P01 = P1*(T01/T1)^(Gamma/(Gamma-1));
        P2 = P1*((1+Gamma*M1^2)/(1+Gamma));
        T2 = T1/((M1*(P1/P2))^2);
        V2 = C;
        P02 = P01*((1+Gamma*M1^2)/(1+Gamma));
        T02 = T01/((M1*(P1/P2))^2);

        area_mach = @(M) (1/M)*((2/(Gamma+1)*(1 + ((Gamma-1)/2)*M^2))^((Gamma+1)/(2*(Gamma-1)))) - A2_A3;
        M3 = fzero(area_mach, 2.6);
        T3 = T02/(1+((Gamma-1)/2)*M3^2);
        P3 = P02*(T3/T02)^(Gamma/(Gamma-1));
        a3 = sqrt(Gamma*Rgas*T3);
        V3 = M3*a3;

        Mach_inlet(i) = M1; Mach_outlet(i) = M3;
        Vel_inlet(i) = V1; Vel_throat(i) = V2; Vel_outlet(i) = V3;
        P_inlet(i) = P1/1000; P_throat(i) = P2/1000; P_outlet(i) = P3/1000;
        T_inlet(i) = T1; T_throat(i) = T2; T_outlet(i) = T3;
    end

    % Plot Mach vs time
    figure;
    plot(t, Mach_inlet,'b-','LineWidth',2); hold on;
    plot(t, Mach_throat,'r--','LineWidth',2);
    plot(t, Mach_outlet,'g-.','LineWidth',2);
    xlabel('Time [s]'); ylabel('Mach Number');
    title('Mach Number vs Time'); grid on; legend('Inlet','Throat','Outlet');

    % Plot Velocity vs time
    figure;
    plot(t, Vel_inlet,'b-','LineWidth',2); hold on;
    plot(t, Vel_throat,'r--','LineWidth',2);
    plot(t, Vel_outlet,'g-.','LineWidth',2);
    xlabel('Time [s]'); ylabel('Velocity [m/s]');
    title('Velocity vs Time'); grid on; legend('Inlet','Throat','Outlet');

    % Plot Pressure vs time
    figure;
    plot(t, P_inlet,'b-','LineWidth',2); hold on;
    plot(t, P_throat,'r--','LineWidth',2);
    plot(t, P_outlet,'g-.','LineWidth',2);
