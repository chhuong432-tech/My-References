

%% Physical constants
Gamma = 1.4;              % Specific heat ratio for air
Rgas  = 287;              % Gas constant [J/(kg·K)]
Mair  = 29e-3;            % Molar mass of air [kg/mol]

% Atmospheric conditions at 11 km altitude
P1 = 22.632;              % Static pressure [kPa]
T1 = 216.65;              % Static temperature [K]

% Geometry
A = 43;                   % Flow area [m^2]

% Delta range (shock angle or deflection angle)
Delta_range = 25:1:45;  % Degrees
n = length(Delta_range); % Number of iterations

% Preallocate cell array
ResultsCell = cell(n,13);  % n rows, 13 columns

for i = 1:n
    Delta = Delta_range(i);
    M1 = 1 / sin(deg2rad(Delta));
    T01 = T1 * (1 + ((Gamma-1)/2) * M1^2);
    P01 = P1 * ((T01/T1)^(Gamma/(Gamma-1)));
    C1 = sqrt(Gamma * Rgas * T1);
    V1 = M1 * C1;
       
% Find T2, T02, M2
    T2 = T1 * (1 + (Gamma - 1)/2 * M1^2) *((2 * M1^2 - (Gamma - 1)) / ((Gamma + 1)^2 * M1^2));
    M2 = sqrt(1 + (Gamma - 1)/2 * M1^2) / (Gamma * M1^2 - (Gamma - 1)/2);
    T02= T2*(1+((Gamma-1)/2)*M2^2);

% Mass Flow Rate
    A=42;
    pho1=(P1/(Rgas*T1)); %  density (kg/m^3)
    m=V1*pho1*A;
    Cp=(((Gamma-1)/Gamma)*Rgas)*(T02-T01);
    Q=m*Cp;

% Mass of conseravation
    pho2 = V1* (pho1/m);

% Pho2
    P2 = pho2 * Rgas * T2;

% Outlat Stagenation point 2-02
    P02 = P2*((T02/T2)^(Gamma/(Gamma-1)));

% Store values in cell array
    ResultsCell{i,1} = Delta;
    ResultsCell{i,2} = M1;
    ResultsCell{i,3} = T01;
    ResultsCell{i,4} = P01;
    ResultsCell{i,5} = C1;
    ResultsCell{i,6} = V1;
    ResultsCell{i,7} = M2;
    ResultsCell{i,8} = T2;
    ResultsCell{i,9} = T02;
    ResultsCell{i,10} = P2;
    ResultsCell{i,11} = P02;
    ResultsCell{i,12} = Cp;
    ResultsCell{i,13} = m;
    ResultsCell{i,14} = Q;

end

% Convert to table
Results = cell2table(ResultsCell, 'VariableNames', {'Delta_deg', 'MachNumber1', 'T01_K', 'P01_KPa', 'C1_m/s', 'V1_m/s', ...
    'Machnumber2', 'T2_K', 'T02_K', 'P2_KPa', 'P02_KPa', 'Cp2_J/Kg', 'Mass FLow Rate_Kg/s', 'Q_W'});

% Display
disp(Results)


