
% Parameters
U_inf = 250;       % Freestream velocity (normalized)
c = 668;           % Chord length (normalized)
H = 0.022 * c;   % Vertical height
rho = 3.639840427285616e-04;     % Air density [kg/m^3]
y= 53198148.21;

% Define velocity profile at surface 2
u2 = @(y) U_inf * (0.75 - 0.25 * cos(pi * y / H));

% Integrate momentum deficit
integrand = @(y) U_inf^2 - u2(y).^2;
D = rho * integral(integrand, 0, H);

% Drag coefficient
CD = 2*D / (0.5 * rho * U_inf^2 * c);
Av= u2(y)/U_inf;

% Display result
fprintf('Speed_output at y= %.4f m/s\n', u2(y));
fprintf('Average= %4f ', Av);
fprintf('Drag Force D = %.6f N/m\n', D);
fprintf('Drag Coefficient CD = %.6f\n', CD);

