function [v, M, a, rho, T, p] = airspeed_from_pitot(Pt, Ps, h)
% Compute airspeed and Mach from pitot-static pressures and altitude

% Inputs: Pt (Pa), Ps (Pa), h (m)
% Outputs: v (m/s), M (-), a (m/s), rho (kg/m^3), T (K), p (Pa)

% Constants
gamma = 1.4; 
R = 287;     % J/(kg*K) 
g = 9.81;    % m/s^2 
L = 0.0065;     % K/m 
T0 = 288.15;    % Sea-level temperature [K] 
p0 = 101325;    % Sea-level pressure [Pa]

% Standard atmosphere (troposphere)
T = T0 - L*h;
p = p0 * (T/T0)^(g/(L*R));
rho = p / (R*T);
a = sqrt(gamma * R * T);

% Compressible isentropic Mach from Pt/Ps
PR = Pt / Ps;
M = sqrt( (2/(gamma-1)) * ( PR^((gamma-1)/gamma) - 1 ) );

% Velocity
v = M * a;

% Display results
fprintf('Altitude h = %.0f m\n', h);
fprintf('Mach M = %.3f, Velocity v = %.2f m/s\n', M, v);
fprintf('Velocity v = %.2f m/s\n', v);

end

% Put this into the window command 
% [v, M, a, rho, T, p] = airspeed_from_pitot(50000, 30000, 5000);

