syms y
U_inf = 100;  % example freestream velocity
H = 1;        % channel height
rho = 1.225;  % air density
C = 1;        % chord length

U_y = U_inf * (0.75 - 0.25 * cos(pi * y / H));
momentum_deficit = (U_inf - U_y) * U_y;

D = rho * int(momentum_deficit, y, 0, H);
Cd = D / (0.5 * rho * U_inf^2 * C);
Cd_val = double(Cd);


