clc; clear; close all;

% Parameters
c = 1.2;              % Chord length
t = 0.12;           % Thickness ratio (0.12 = NACA 0012)
n = 200;            % Number of points

% x distribution (cosine spacing for smooth leading edge)
beta = linspace(0, pi, n);
x = (c/2)*(1 - cos(beta));

% Thickness distribution (NACA equation)
yt = 15*t*c*( 0.2969*(x/c)- 0.1260*(x/c)- 0.3516*(x/c).^2 + 0.2820*(x/c).^3- 0.1015*(x/c).^4 );

% Upper and lower surfaces
xu = x;      yu = yt;
xl = x;      yl = -yt;

% Plot
figure;
plot(xu, yu, 'k', 'LineWidth', 1.5); hold on;
plot(xl, yl, 'k', 'LineWidth', 1.5);
axis equal;
grid on;

xlabel('x');
ylabel('y');

title('Symmetric Tial Airfoil ');


