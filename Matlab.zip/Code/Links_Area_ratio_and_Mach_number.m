

%%
Aratio= 3;
g=1.4;

fcn = @(M) (1./M).*( (2/(g+1)) .* (1+(g-1)/2*M.^2) ) .^ ((g+1)/(2*(g-1))) - Aratio;

Mv = linspace(0, 4);
idx = find(diff(sign(fcn(Mv))))
for k = 1:numel(idx)
    [Mc(k),fv(k)] = fzero(fcn, Mv(idx(k)));
end

figure
plot(Mv, fcn(Mv), '-b', Mc, zeros(size(Mc)),'sr')
grid
text(Mc,zeros(size(Mc)),compose(' \\leftarrow %.4f',Mc))


% Mc = Mach numbers that make the area ratio equal to 4 (both subsonic and supersonic solutions).

% fv = residuals of the function at those Mach numbers (should be ≈ 0).



