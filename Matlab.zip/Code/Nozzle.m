%% Converging–Diverging nozzle: Subsonic -> Sonic -> Supersonic (robust)
clear; clc;

% Constants
gamma = 1.4;
R     = 287;

% Grid and geometry
Nx = 201;
x  = linspace(-1, 1, Nx);            % axial coordinate [m]
A  = 1 + 2.2*(x).^2;                 % area profile; minimum at x=0
Ath = min(A);                        % throat area
Ar  = A ./ Ath;                      % area ratio A/A*

% Total (stagnation) conditions
T0 = 300;                            % K
p0 = 101325;                         % Pa

% Area–Mach relation A/A* = f(M)
Ar_of_M = @(M) (1./M) .* ((2/(gamma+1)) .* (1 + (gamma-1)/2 .* M.^2)) .^ ((gamma+1)/(2*(gamma-1)));
residual = @(M, Ar_target) Ar_of_M(M) - Ar_target;

% Preallocate
M = zeros(size(x));

% Indices: left half subsonic, center throat sonic, right half supersonic
i_throat = find(A == Ath, 1, 'first');   % index of throat
if isempty(i_throat), i_throat = ceil(Nx/2); end

for i = 1:Nx
    Ar_i = Ar(i);

    if i == i_throat
        M(i) = 1.0;
        continue;
    end

    if i < i_throat
        % Subsonic branch: bracket in (0,1)
        % Use a small lower bound to avoid division by zero
        bracket = [1e-6, 0.999];
        % Ensure there is a sign change in the bracket; adapt if needed
        f_lo = residual(bracket(1), Ar_i);
        f_hi = residual(bracket(2), Ar_i);
        if f_lo * f_hi > 0
            % If no sign change, push the upper bound closer to 1
            bracket = [1e-6, 0.999999];
            f_lo = residual(bracket(1), Ar_i);
            f_hi = residual(bracket(2), Ar_i);
        end
        % Try fzero with bracket; if it complains, fall back to a scalar guess
        try
            M(i) = fzero(@(M) residual(M, Ar_i), bracket);
        catch
            M(i) = fzero(@(M) residual(M, Ar_i), 0.3); % reasonable subsonic guess
        end

    else
        % Supersonic branch: bracket in (1, Mmax)
        bracket = [1.0001, 5.0];
        f_lo = residual(bracket(1), Ar_i);
        f_hi = residual(bracket(2), Ar_i);
        if f_lo * f_hi > 0
            % If no sign change, extend the upper bound
            bracket = [1.0001, 10.0];
            f_lo = residual(bracket(1), Ar_i);
            f_hi = residual(bracket(2), Ar_i);
        end
        try
            M(i) = fzero(@(M) residual(M, Ar_i), bracket);
        catch
            M(i) = fzero(@(M) residual(M, Ar_i), 2.5); % reasonable supersonic guess
        end
    end

    % Guard against numerical drift at the throat
    if abs(M(i) - 1) < 1e-6
        M(i) = (i < i_throat) * 0.999 + (i > i_throat) * 1.001;
    end
end

% Isentropic static properties
T = T0 ./ (1 + (gamma-1)/2 .* M.^2);
p = p0 .* (T ./ T0) .^ (gamma/(gamma-1));      % same as (1 + (g-1)/2 M^2)^(-g/(g-1))

% Speed of sound and velocity
a = sqrt(gamma * R .* T);
v = M .* a;

%% Plot: Area and Mach (dual axes)
figure('Color',[1 1 1]);
yyaxis left
plot(x, Ar, 'k-', 'LineWidth', 2); grid on; box on;
ylabel('Area ratio A/A*');
yyaxis right
plot(x, M, 'b-', 'LineWidth', 2);
hold on; plot(x(i_throat), 1, 'ro', 'MarkerFaceColor','r');
ylabel('Mach number M');
xlabel('Axial coordinate x [m]');
title('C–D nozzle: area ratio and Mach distribution');
legend('A/A*', 'Mach', 'Throat (M=1)', 'Location','best');

%% Plot: Pressure and Temperature
figure('Color',[1 1 1]);
subplot(2,1,1);
plot(x, p/1000, 'r-', 'LineWidth', 2); grid on; box on;
ylabel('Static pressure p [kPa]');
title('Static pressure and temperature along nozzle');
subplot(2,1,2);
plot(x, T, 'm-', 'LineWidth', 2); grid on; box on;
xlabel('Axial coordinate x [m]');
ylabel('Static temperature T [K]');

%% Plot: Velocity and speed of sound
figure('Color',[1 1 1]);
plot(x, v, 'c-', 'LineWidth', 2); hold on;
plot(x, a, 'g--', 'LineWidth', 1.5);
grid on; box on;
xlabel('Axial coordinate x [m]');
ylabel('Velocity / Speed of sound [m/s]');
title('Velocity and speed of sound along nozzle');
legend('Velocity v(x)', 'Speed of sound a(x)', 'Location','best');
